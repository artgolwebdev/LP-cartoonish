
  # Artistic Cartoonish Landing Page

  This is a code bundle for Artistic Cartoonish Landing Page. The original project is available at https://www.figma.com/design/wCSsKQlhlTI0yUKFSH0EWZ/Artistic-Cartoonish-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  